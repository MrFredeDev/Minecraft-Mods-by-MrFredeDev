package com.promptcraft.advancedmining.limitbreaker;

import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.AnvilUpdateEvent;

/**
 * AnvilLimitBreakerHandler — NeoForge 26.1
 *
 * Key API change from 1.20.1 Forge:
 *   In 26.1, enchantments are stored as the DataComponents.ENCHANTMENTS
 *   component (ItemEnchantments). There is no longer EnchantmentHelper.getEnchantments()
 *   or EnchantmentHelper.setEnchantments(). Instead, use:
 *
 *     Read:  ItemEnchantments enc = stack.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY);
 *            for (var entry : enc.entrySet()) { entry.getKey() = Holder<Enchantment>; entry.getIntValue() = level }
 *
 *     Write: ItemEnchantments.Mutable mutable = new ItemEnchantments.Mutable(existing);
 *            mutable.set(holder, newLevel);
 *            stack.set(DataComponents.ENCHANTMENTS, mutable.toImmutable());
 *
 * Books use DataComponents.STORED_ENCHANTMENTS instead of ENCHANTMENTS.
 */
public class AnvilLimitBreakerHandler {

    @SubscribeEvent
    public void onAnvilUpdate(AnvilUpdateEvent event) {
        ItemStack left  = event.getLeft();
        ItemStack right = event.getRight();
        if (left.isEmpty() || right.isEmpty()) return;

        // Read enchantments from both items using the component system
        boolean rightIsBook = right.is(Items.ENCHANTED_BOOK);
        ItemEnchantments rightEnch = rightIsBook
                ? right.getOrDefault(net.minecraft.core.component.DataComponents.STORED_ENCHANTMENTS,
                                     ItemEnchantments.EMPTY)
                : right.getOrDefault(net.minecraft.core.component.DataComponents.ENCHANTMENTS,
                                     ItemEnchantments.EMPTY);

        ItemEnchantments leftEnch = left.getOrDefault(
                net.minecraft.core.component.DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY);

        if (rightEnch.isEmpty()) return;

        // Build mutable result starting from left item's enchantments
        ItemEnchantments.Mutable result = new ItemEnchantments.Mutable(leftEnch);
        int xpCost   = 0;
        boolean bump = false;

        for (var entry : rightEnch.entrySet()) {
            Holder<Enchantment> holder = entry.getKey();
            int rightLevel = entry.getIntValue();
            int leftLevel  = leftEnch.getLevel(holder);

            // Resolve registry key for LimitBreakerConfig lookup
            ResourceLocation enchKey = holder.unwrapKey()
                    .map(k -> k.location()).orElse(null);
            if (enchKey == null) continue;

            int extMax = LimitBreakerConfig.getExtendedMax(enchKey);
            if (extMax < 0) continue;

            // Vanilla combining rule: same level → +1, else take the higher
            int combined = (leftLevel == rightLevel) ? leftLevel + 1
                                                     : Math.max(leftLevel, rightLevel);

            // Only intervene above vanilla cap but within our extended cap
            if (combined > holder.value().getMaxLevel() && combined <= extMax) {
                result.set(holder, combined);
                xpCost += combined * 3;
                bump = true;
            }
        }

        if (!bump) return;

        // Build output item with updated enchantment component
        ItemStack output;
        boolean leftIsBook = left.is(Items.ENCHANTED_BOOK) || left.is(Items.BOOK);
        if (leftIsBook) {
            output = new ItemStack(Items.ENCHANTED_BOOK);
            output.set(net.minecraft.core.component.DataComponents.STORED_ENCHANTMENTS,
                       result.toImmutable());
        } else {
            output = left.copy();
            output.set(net.minecraft.core.component.DataComponents.ENCHANTMENTS,
                       result.toImmutable());
        }

        output.setRepairCost(left.getBaseRepairCost() + 1);
        event.setOutput(output);
        event.setCost(Math.max(1, xpCost));
        event.setMaterialCost(1);
    }
}
