package com.promptcraft.advancedmining.limitbreaker;

import net.minecraft.resources.ResourceLocation;
import java.util.*;

/**
 * LimitBreakerConfig — NeoForge 26.1
 *
 * Defines extended max levels for vanilla enchantments.
 * Used by two mechanisms:
 *
 *   1. AnvilLimitBreakerHandler — anvil combining beyond vanilla cap (Java event)
 *   2. data/minecraft/enchantment/*.json overrides — raises max_level for the
 *      enchanting table (JSON files in this mod's resources override vanilla)
 *
 * To adjust limits: edit the static block below. No other file needs changing.
 */
public final class LimitBreakerConfig {

    public static final Map<ResourceLocation, Integer> EXTENDED_MAX;

    static {
        Map<ResourceLocation, Integer> m = new HashMap<>();
        // Tool
        m.put(rl("efficiency"),              8);
        m.put(rl("fortune"),                 5);
        m.put(rl("unbreaking"),              5);
        // Weapon
        m.put(rl("sharpness"),               8);
        m.put(rl("smite"),                   8);
        m.put(rl("bane_of_arthropods"),      8);
        m.put(rl("looting"),                 7);
        m.put(rl("sweeping_edge"),           4);
        m.put(rl("knockback"),               4);
        m.put(rl("fire_aspect"),             3);
        // Armour
        m.put(rl("protection"),              6);
        m.put(rl("fire_protection"),         6);
        m.put(rl("blast_protection"),        6);
        m.put(rl("projectile_protection"),   6);
        m.put(rl("feather_falling"),         6);
        m.put(rl("thorns"),                  4);
        m.put(rl("depth_strider"),           4);
        m.put(rl("swift_sneak"),             4);
        // Ranged
        m.put(rl("power"),                   8);
        m.put(rl("punch"),                   4);
        m.put(rl("quick_charge"),            4);
        m.put(rl("piercing"),                6);
        EXTENDED_MAX = Collections.unmodifiableMap(m);
    }

    private LimitBreakerConfig() {}

    private static ResourceLocation rl(String name) {
        return ResourceLocation.fromNamespaceAndPath("minecraft", name);
    }

    /** Returns the extended max, or -1 if not configured. */
    public static int getExtendedMax(ResourceLocation key) {
        return EXTENDED_MAX.getOrDefault(key, -1);
    }
}
