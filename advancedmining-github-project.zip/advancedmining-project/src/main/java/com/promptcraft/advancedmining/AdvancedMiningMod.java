package com.promptcraft.advancedmining;

import com.promptcraft.advancedmining.events.MiningEventHandler;
import com.promptcraft.advancedmining.limitbreaker.AnvilLimitBreakerHandler;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * AdvancedMiningMod — NeoForge 26.1.0.x (Minecraft 26.1 "Tiny Takeover")
 *
 * Key 26.1 changes from 1.20.1 Forge:
 *   • Mod loader:  Forge          → NeoForge
 *   • Java:        17             → 25
 *   • Packages:    net.minecraftforge → net.neoforged.neoforge
 *   • Constructor: now receives IEventBus as an injected parameter
 *   • Enchantments: class-based   → data-driven JSON + ResourceKey references
 *   • Obfuscation: removed; official Mojang names used everywhere
 */
@Mod(AdvancedMiningMod.MOD_ID)
public class AdvancedMiningMod {

    public static final String MOD_ID = "advancedmining";
    public static final Logger LOGGER = LogManager.getLogger();

    /**
     * NeoForge 26.1: the mod event bus is injected directly into the constructor.
     * No more FMLJavaModLoadingContext.get().getModEventBus().
     */
    public AdvancedMiningMod(IEventBus modEventBus) {
        // Register game-world event listeners (block break, anvil update, etc.)
        NeoForge.EVENT_BUS.register(new MiningEventHandler());
        NeoForge.EVENT_BUS.register(new AnvilLimitBreakerHandler());

        LOGGER.info("[AdvancedMining] Excavator | VeinMiner | LimitBreaker loaded for Minecraft 26.1");
    }
}
