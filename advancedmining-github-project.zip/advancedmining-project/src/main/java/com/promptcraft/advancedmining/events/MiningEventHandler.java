package com.promptcraft.advancedmining.events;

import com.promptcraft.advancedmining.ModEnchantments;
import com.promptcraft.advancedmining.enchantments.ExcavatorEnchantment;
import com.promptcraft.advancedmining.enchantments.VeinMinerEnchantment;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.level.BlockEvent;

import java.util.Optional;

/**
 * MiningEventHandler — NeoForge 26.1
 *
 * Key change from 1.20.1 Forge:
 *   In 26.1, enchantments are data-driven. To look up a custom enchantment
 *   at runtime, use the level's RegistryAccess to resolve the ResourceKey
 *   into a Holder<Enchantment>, then call EnchantmentHelper.getItemEnchantmentLevel
 *   with that Holder.
 *
 *   Old (1.20.1 Forge):
 *     int level = EnchantmentHelper.getItemEnchantmentLevel(ModEnchantments.EXCAVATOR.get(), stack);
 *
 *   New (26.1 NeoForge):
 *     var reg = serverLevel.registryAccess().registryOrThrow(Registries.ENCHANTMENT);
 *     Optional<Holder.Reference<Enchantment>> holder = reg.getHolder(ModEnchantments.EXCAVATOR);
 *     int level = holder.map(h -> EnchantmentHelper.getItemEnchantmentLevel(h, stack)).orElse(0);
 */
public class MiningEventHandler {

    @SubscribeEvent
    public void onBlockBreak(BlockEvent.BreakEvent event) {
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) return;

        Player player = event.getPlayer();
        if (player == null) return;

        ItemStack stack = player.getMainHandItem();
        if (stack.isEmpty()) return;

        // Resolve enchantment holders from the world's live registry
        var enchReg = serverLevel.registryAccess().registryOrThrow(Registries.ENCHANTMENT);

        // ── Excavator ────────────────────────────────────────────────────────
        Optional<Holder.Reference<Enchantment>> excavatorHolder =
                enchReg.getHolder(ModEnchantments.EXCAVATOR);

        excavatorHolder.ifPresent(holder -> {
            int excavLevel = EnchantmentHelper.getItemEnchantmentLevel(holder, stack);
            if (excavLevel > 0) {
                ExcavatorEnchantment.handleExcavation(
                        event, serverLevel, player, stack, excavLevel);
            }
        });

        // ── Vein Miner ───────────────────────────────────────────────────────
        Optional<Holder.Reference<Enchantment>> veinHolder =
                enchReg.getHolder(ModEnchantments.VEIN_MINER);

        veinHolder.ifPresent(holder -> {
            int veinLevel = EnchantmentHelper.getItemEnchantmentLevel(holder, stack);
            if (veinLevel > 0) {
                VeinMinerEnchantment.handleVeinMining(
                        event, serverLevel, player, stack, veinLevel);
            }
        });
    }
}
