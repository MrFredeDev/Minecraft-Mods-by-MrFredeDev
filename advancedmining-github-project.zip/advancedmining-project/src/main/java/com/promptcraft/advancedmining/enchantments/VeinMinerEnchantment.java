package com.promptcraft.advancedmining.enchantments;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.neoforge.event.level.BlockEvent;

import java.util.*;

/**
 * VeinMinerEnchantment — NeoForge 26.1 logic class.
 *
 * No longer extends Enchantment. The enchantment is declared in:
 *   data/advancedmining/enchantment/vein_miner.json
 *
 * BFS ore-vein traversal. Ore tags used so deepslate variants count
 * as the same vein. Hard-capped per tier: I=64, II=128, III=256.
 */
public final class VeinMinerEnchantment {

    private static final int[] VEIN_CAP = {0, 64, 128, 256};

    private static final List<TagKey<Block>> ORE_TAGS = List.of(
            BlockTags.COAL_ORES, BlockTags.IRON_ORES, BlockTags.GOLD_ORES,
            BlockTags.COPPER_ORES, BlockTags.LAPIS_ORES, BlockTags.REDSTONE_ORES,
            BlockTags.EMERALD_ORES, BlockTags.DIAMOND_ORES);

    private static final ThreadLocal<Boolean> IS_VEIN_MINING =
            ThreadLocal.withInitial(() -> false);

    private VeinMinerEnchantment() {}

    public static void handleVeinMining(BlockEvent.BreakEvent event,
                                        ServerLevel level,
                                        Player player,
                                        ItemStack stack,
                                        int enchLevel) {
        if (IS_VEIN_MINING.get()) return;
        BlockPos origin      = event.getPos();
        BlockState origState = level.getBlockState(origin);
        if (!isOre(origState)) return;

        int cap = (enchLevel < VEIN_CAP.length) ? VEIN_CAP[enchLevel] : 64;
        List<BlockPos> vein  = bfs(origin, origState, level, cap);

        IS_VEIN_MINING.set(true);
        try {
            for (BlockPos pos : vein) {
                if (pos.equals(origin)) continue;
                BlockState state = level.getBlockState(pos);
                if (state.isAir()) continue;
                if (!player.hasCorrectToolForDrops(state)) continue;

                BlockEntity be = level.getBlockEntity(pos);
                state.getBlock().playerDestroy(level, player, pos, state, be, stack);
                level.removeBlock(pos, false);
                level.levelEvent(2001, pos, Block.getId(state));

                if (!player.isCreative() && stack.isDamageableItem()) {
                    stack.hurtAndBreak(1, player,
                            p -> p.broadcastBreakEvent(EquipmentSlot.MAINHAND));
                    if (stack.isEmpty()) break;
                }
            }
        } finally {
            IS_VEIN_MINING.set(false);
        }
    }

    /** BFS over 6 cardinal neighbours, capped at maxSize. */
    private static List<BlockPos> bfs(BlockPos origin, BlockState origState,
                                       ServerLevel level, int maxSize) {
        List<BlockPos>   result  = new ArrayList<>();
        Set<BlockPos>    visited = new HashSet<>();
        Deque<BlockPos>  queue   = new ArrayDeque<>();
        queue.add(origin);
        visited.add(origin);

        while (!queue.isEmpty() && result.size() < maxSize) {
            BlockPos current = queue.poll();
            result.add(current);
            for (Direction dir : Direction.values()) {
                BlockPos nb = current.relative(dir);
                if (visited.contains(nb)) continue;
                visited.add(nb);
                if (sameVein(origState, level.getBlockState(nb))) {
                    queue.add(nb);
                }
            }
        }
        return result;
    }

    private static boolean sameVein(BlockState origin, BlockState candidate) {
        if (candidate.is(origin.getBlock())) return true;
        for (TagKey<Block> tag : ORE_TAGS) {
            if (origin.is(tag) && candidate.is(tag)) return true;
        }
        return false;
    }

    private static boolean isOre(BlockState state) {
        for (TagKey<Block> tag : ORE_TAGS) {
            if (state.is(tag)) return true;
        }
        return state.is(Blocks.NETHER_QUARTZ_ORE)
            || state.is(Blocks.ANCIENT_DEBRIS)
            || state.is(Blocks.NETHER_GOLD_ORE);
    }
}
