package com.promptcraft.advancedmining;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.enchantment.Enchantment;

/**
 * ModEnchantments — NeoForge 26.1
 *
 * In Minecraft 26.1, enchantments are fully data-driven (since 1.21).
 * There is no longer an Enchantment class to extend or a DeferredRegister
 * to populate. Instead:
 *
 *   1. Declare a ResourceKey<Enchantment> for each custom enchantment.
 *   2. Create a matching JSON file in:
 *        src/main/resources/data/advancedmining/enchantment/<name>.json
 *      This JSON file IS the registration — it defines max_level, cost,
 *      supported items, and effect components.
 *
 * To look up the enchantment at runtime, use the ResourceKey with the
 * level's RegistryAccess (see MiningEventHandler for usage).
 */
public final class ModEnchantments {

    /**
     * Excavator — area mining enchantment (max level VII).
     * Matches:  data/advancedmining/enchantment/excavator.json
     */
    public static final ResourceKey<Enchantment> EXCAVATOR =
            ResourceKey.create(
                    Registries.ENCHANTMENT,
                    ResourceLocation.fromNamespaceAndPath(AdvancedMiningMod.MOD_ID, "excavator"));

    /**
     * Vein Miner — BFS ore-vein harvesting (max level III).
     * Matches:  data/advancedmining/enchantment/vein_miner.json
     */
    public static final ResourceKey<Enchantment> VEIN_MINER =
            ResourceKey.create(
                    Registries.ENCHANTMENT,
                    ResourceLocation.fromNamespaceAndPath(AdvancedMiningMod.MOD_ID, "vein_miner"));

    private ModEnchantments() {}
}
