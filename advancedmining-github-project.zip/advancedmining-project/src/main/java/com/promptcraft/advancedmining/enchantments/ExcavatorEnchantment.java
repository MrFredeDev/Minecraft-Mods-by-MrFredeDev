package com.promptcraft.advancedmining.enchantments;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.neoforge.event.level.BlockEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * ExcavatorEnchantment — NeoForge 26.1 logic class.
 *
 * No longer extends Enchantment. The enchantment is declared in:
 *   data/advancedmining/enchantment/excavator.json
 *
 * This class only contains the block-break side-effects.
 *
 *  Tier  Face    Depth   Volume
 *  I     3x3     1       ~8 extra blocks
 *  II    3x3     2       ~17
 *  III   3x3     3       ~26
 *  IV    4x4     1       ~15
 *  V     4x4     2       ~31
 *  VI    4x4     3       ~47
 *  VII   4x4     4       ~63
 */
public final class ExcavatorEnchantment {

    private static final ThreadLocal<Boolean> IS_EXCAVATING =
            ThreadLocal.withInitial(() -> false);

    private ExcavatorEnchantment() {}

    public static void handleExcavation(BlockEvent.BreakEvent event,
                                        ServerLevel level,
                                        Player player,
                                        ItemStack stack,
                                        int enchLevel) {
        if (IS_EXCAVATING.get()) return;
        Direction face = getTargetedFace(player, level);
        if (face == null) return;

        List<BlockPos> extras = buildVolume(event.getPos(), face, enchLevel);

        IS_EXCAVATING.set(true);
        try {
            for (BlockPos pos : extras) {
                BlockState state = level.getBlockState(pos);
                if (state.isAir()) continue;
                if (state.getDestroySpeed(level, pos) < 0f) continue;
                if (!player.hasCorrectToolForDrops(state)) continue;

                BlockEntity be = level.getBlockEntity(pos);
                state.getBlock().playerDestroy(level, player, pos, state, be, stack);
                level.removeBlock(pos, false);
                level.levelEvent(2001, pos, Block.getId(state));

                if (!player.isCreative() && stack.isDamageableItem()) {
                    stack.hurtAndBreak(1, player,
                            p -> p.broadcastBreakEvent(EquipmentSlot.MAINHAND));
                    if (stack.isEmpty()) break;
                }
            }
        } finally {
            IS_EXCAVATING.set(false);
        }
    }

    private static Direction getTargetedFace(Player player, ServerLevel level) {
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getViewVector(1.0f).scale(6.0));
        BlockHitResult hit = level.clip(new ClipContext(
                eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player));
        return hit.getDirection();
    }

    private static List<BlockPos> buildVolume(BlockPos origin, Direction hitFace, int tier) {
        int[] dim    = dims(tier);
        int faceSize = dim[0];
        int depth    = dim[1];
        Direction inward = hitFace.getOpposite();
        Direction[] span = spanAxes(inward.getAxis());
        int start = -((faceSize - 1) / 2);
        int end   = start + faceSize - 1;
        List<BlockPos> result = new ArrayList<>();
        for (int d = 0; d < depth; d++) {
            for (int a = start; a <= end; a++) {
                for (int b = start; b <= end; b++) {
                    int dx = inward.getStepX()*d + span[0].getStepX()*a + span[1].getStepX()*b;
                    int dy = inward.getStepY()*d + span[0].getStepY()*a + span[1].getStepY()*b;
                    int dz = inward.getStepZ()*d + span[0].getStepZ()*a + span[1].getStepZ()*b;
                    BlockPos c = origin.offset(dx, dy, dz);
                    if (!c.equals(origin)) result.add(c);
                }
            }
        }
        return result;
    }

    private static int[] dims(int tier) {
        return switch (tier) {
            case 1  -> new int[]{3, 1};
            case 2  -> new int[]{3, 2};
            case 3  -> new int[]{3, 3};
            case 4  -> new int[]{4, 1};
            case 5  -> new int[]{4, 2};
            case 6  -> new int[]{4, 3};
            case 7  -> new int[]{4, 4};
            default -> new int[]{3, 1};
        };
    }

    private static Direction[] spanAxes(Direction.Axis depthAxis) {
        return switch (depthAxis) {
            case X -> new Direction[]{Direction.UP,   Direction.SOUTH};
            case Y -> new Direction[]{Direction.EAST, Direction.SOUTH};
            case Z -> new Direction[]{Direction.EAST, Direction.UP};
        };
    }
}
